
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewpoint" content="width=device-width, initial-scale=1.0">
    <title>Add Results</title>
    <link rel="stylesheet" href="css/form.css">
     <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
   
</head>
<body>
	<h1>Add Results</h1>
	 <div class="main">
        <form action="" method="post">
            <fieldset>
            <h4>Enter Marks</h4>


                <select name="class_name">
                	<option selected disabled>Select Year</option>
                	<option value="one">1st Year</option>
                	<option value="two">2nd Year</option>
                	<option value="three">3rd Year</option>
                	<option value="four">4th Year</option>
                	<option value="five">Final Year</option>
                </select>
                <input type="text" name="rno" placeholder="Student's Roll Number">
                <input type="text" name="p1" id="" placeholder="Paper 1 - Marks">
                <input type="text" name="p2" id="" placeholder="Paper 2 - Marks">
                <input type="text" name="p3" id="" placeholder="Paper 3 - Marks">
                <input type="text" name="p4" id="" placeholder="Paper 4 - Marks">
                <input type="text" name="p5" id="" placeholder="Paper 5 - Marks">
                <button><input type="submit" value="Generate"></button>
                <button>Cancel</button>


            </fieldset>
        </form>
    </div>
</body>
</html>
