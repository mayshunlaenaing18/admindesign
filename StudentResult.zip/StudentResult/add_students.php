<!doctype html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Add Students</title>
	<link rel="stylesheet" href="css/form.css">
     <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
   
</head>
<body>
	<h1>Add Student</h1>
	<div class="main">
        <form action="" method="post">
            <fieldset>
                <h4>Add Student</h4>
                <input type="text" name="roll_no" placeholder="Roll No"><br><br>
                <select name="class_name"><option selected disabled>Select Class</option>
                	<option value="Demo Class">Demo Class</option>
                	<option value="Eight">Eight</option>
                	<option value="Nine">Nine</option>
                	<option value="Seven">Seven</option>
                	<option value="Ten">Ten</option>
                </select><br><br>                
                <input type="submit" value="Submit">
            </fieldset>
        </form>
    </div>

</body>
</html>